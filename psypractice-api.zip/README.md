# PsyPractice Manual Search API

A Flask-based API that searches across PDF therapy manuals for use with ChatGPT Actions.